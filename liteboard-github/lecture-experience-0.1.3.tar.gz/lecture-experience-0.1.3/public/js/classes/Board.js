export default function Board(pathsData, image, zoom) {
  this.pathsData = pathsData;
  this.image = image;
  this.zoom = zoom;
  this.centerView = null;
}
