export default function Attachment(fileContent, name, type) {
  this.file = fileContent;
  this.name = name;
  this.type = type;
}
